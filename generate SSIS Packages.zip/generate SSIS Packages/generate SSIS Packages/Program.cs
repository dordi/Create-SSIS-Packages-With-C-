﻿using Microsoft.SqlServer.Dts.Pipeline.Wrapper;
using Microsoft.SqlServer.Dts.Runtime;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace generate_SSIS_Packages
{
    class Program
    {
        /// <summary>

        /// Creates a data flow package with a source and destination sharing a connection manager.

        /// The source reads all columns from the [DimCustomer] table, and the destination writes

        /// them to the [DimCustomer_Copy] table.

        /// </summary>

        static void Main(string[] args)

        {
            SqlConnection conn = new SqlConnection(@"Data Source=192.168.35.239;User ID=sa;Password=Coriolis12;Initial Catalog=PROD_WorkFlow;Persist Security Info=True;");
            SqlCommand cmd = new SqlCommand("SELECT	[name] FROM sys.tables WHERE [type] = 'U' AND create_date > '2018-11-23 14:41:41.537'", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                Package package = new Package();

                // Add Data Flow Task

                Executable dataFlowTask = package.Executables.Add("STOCK:PipelineTask");


                // Set the name (otherwise it will be a random GUID value)

                TaskHost taskHost = dataFlowTask as TaskHost;

                taskHost.Name = dr["name"].ToString();


                // We need a reference to the InnerObject to add items to the data flow

                MainPipe pipeline = taskHost.InnerObject as MainPipe;


                package.Parameters.Add("Dest_ConnectionString", TypeCode.String);
                package.Parameters["Dest_ConnectionString"].Value = @"Data Source=192.168.35.239;User ID=sa;Password=Coriolis12;Initial Catalog=PROD_WorkFlow;Provider=SQLNCLI11.1;Persist Security Info=True;Auto Translate=False;";
                package.Parameters.Add("PREPROD_ConnectionString", TypeCode.String);
                package.Parameters["PREPROD_ConnectionString"].Value = @"Data Source=172.16.2.72\PREPROD1;User ID=phenix;Password=Phenix@1;Initial Catalog=PROD_WorFlow;Provider=SQLNCLI11.1;Persist Security Info=True;Auto Translate=False;";



                //

                // Add connection manager

                //


                ConnectionManager connection = package.Connections.Add("OLEDB");

                connection.Name = "PREPROD";

                connection.ConnectionString = package.Parameters["PREPROD_ConnectionString"].Value.ToString();
                connection.SetExpression("ConnectionString", "@[$Package::PREPROD_ConnectionString]");

                //

                // Add connection manager

                //


                ConnectionManager connectionDest = package.Connections.Add("OLEDB");

                connectionDest.Name = "Dest";

                connectionDest.ConnectionString = package.Parameters["Dest_ConnectionString"].Value.ToString();
                connectionDest.SetExpression("ConnectionString", "@[$Package::Dest_ConnectionString]");

                //

                // Add OLEDB Source

                //


                IDTSComponentMetaData100 srcComponent = pipeline.ComponentMetaDataCollection.New();

                srcComponent.ComponentClassID = "DTSAdapter.OleDbSource";

                srcComponent.ValidateExternalMetadata = true;

                IDTSDesigntimeComponent100 srcDesignTimeComponent = srcComponent.Instantiate();

                srcDesignTimeComponent.ProvideComponentProperties();

                srcComponent.Name = dr["name"] + " Source";


                // Configure it to read from the given table

                srcDesignTimeComponent.SetComponentProperty("AccessMode", 0);

                srcDesignTimeComponent.SetComponentProperty("OpenRowset", "[" + dr["name"].ToString() + "]");


                // Set the connection manager

                srcComponent.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.GetExtendedInterface(connection);

                srcComponent.RuntimeConnectionCollection[0].ConnectionManagerID = connection.ID;


                // Retrieve the column metadata

                srcDesignTimeComponent.AcquireConnections(null);

                srcDesignTimeComponent.ReinitializeMetaData();

                srcDesignTimeComponent.ReleaseConnections();


                //

                // Add OLEDB Destination

                //


                IDTSComponentMetaData100 destComponent = pipeline.ComponentMetaDataCollection.New();

                destComponent.ComponentClassID = "DTSAdapter.OleDbDestination";

                destComponent.ValidateExternalMetadata = true;


                IDTSDesigntimeComponent100 destDesignTimeComponent = destComponent.Instantiate();

                destDesignTimeComponent.ProvideComponentProperties();

                destComponent.Name = dr["name"].ToString();


                destDesignTimeComponent.SetComponentProperty("AccessMode", 3);

                destDesignTimeComponent.SetComponentProperty("OpenRowset", "[" + dr["name"].ToString() + "]");


                // set connection

                destComponent.RuntimeConnectionCollection[0].ConnectionManager = DtsConvert.GetExtendedInterface(connectionDest);

                destComponent.RuntimeConnectionCollection[0].ConnectionManagerID = connectionDest.ID;


                // get metadata

                destDesignTimeComponent.AcquireConnections(null);

                destDesignTimeComponent.ReinitializeMetaData();

                destDesignTimeComponent.ReleaseConnections();


                //

                // Connect source and destination

                //


                IDTSPath100 path = pipeline.PathCollection.New();

                path.AttachPathAndPropagateNotifications(srcComponent.OutputCollection[0], destComponent.InputCollection[0]);


                //

                // Configure the destination

                // 


                IDTSInput100 destInput = destComponent.InputCollection[0];

                IDTSVirtualInput100 destVirInput = destInput.GetVirtualInput();

                IDTSInputColumnCollection100 destInputCols = destInput.InputColumnCollection;

                IDTSExternalMetadataColumnCollection100 destExtCols = destInput.ExternalMetadataColumnCollection;

                IDTSOutputColumnCollection100 sourceColumns = srcComponent.OutputCollection[0].OutputColumnCollection;


                // The OLEDB destination requires you to hook up the external columns

                foreach (IDTSOutputColumn100 outputCol in sourceColumns)

                {

                    // Get the external column id

                    IDTSExternalMetadataColumn100 extCol = (IDTSExternalMetadataColumn100)destExtCols[outputCol.Name];

                    if (extCol != null)

                    {

                        // Create an input column from an output col of previous component.

                        destVirInput.SetUsageType(outputCol.ID, DTSUsageType.UT_READONLY);

                        IDTSInputColumn100 inputCol = destInputCols.GetInputColumnByLineageID(outputCol.ID);

                        if (inputCol != null)

                        {

                            // map the input column with an external metadata column

                            destDesignTimeComponent.MapInputColumn(destInput.ID, inputCol.ID, extCol.ID);

                        }

                    }

                }
                string xmlPackage = "";
                package.SaveToXML(out xmlPackage, null);
                System.IO.File.WriteAllText(@"C:\Users\d.tlili\Documents\SISS Export\" + dr["name"] + ".dtsx", xmlPackage);
            }
        }
    }
}
